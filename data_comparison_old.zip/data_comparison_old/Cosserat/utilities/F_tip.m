function Ftip = F_tip(t)

Ftip = zeros(6,1);

end