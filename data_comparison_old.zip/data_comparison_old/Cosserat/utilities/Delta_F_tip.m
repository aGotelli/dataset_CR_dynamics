function Delta_Ftip = Delta_F_tip(t)

Delta_Ftip = zeros(6,1);

end