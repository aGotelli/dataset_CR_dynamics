function out = getVarName(var)
    out = inputname(1);
end