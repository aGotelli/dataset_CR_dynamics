function M=Ad_g_(R,r)


M=[R zeros(3,3);hat_(r)*R R];